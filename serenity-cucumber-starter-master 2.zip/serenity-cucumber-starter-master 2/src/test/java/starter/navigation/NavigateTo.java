package starter.navigation;

import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Open;

public class NavigateTo {
    public static Performable theSearchHomePage() {
        return Task.where("{0} opens the DuckDuckGo home page",
                Open.browserOn().the(DuckDuckGoHomePage.class));
    }

    public static Performable theJupiterPage() {
        return Task.where("{0} opens the Jupiter home page",
                Open.url("https://jupiter.cloud.planittesting.com/#/home"));
    }

    public static Performable theSauceLabsPage() {
        return Task.where("{0} opens the Sauce Labs home page",
                Open.url("https://www.saucedemo.com/"));
    }
}
