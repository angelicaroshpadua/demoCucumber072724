package starter.navigation;

import net.serenitybdd.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl("https://duckduckgo.com")
public class DuckDuckGoHomePage extends PageObject {
}
