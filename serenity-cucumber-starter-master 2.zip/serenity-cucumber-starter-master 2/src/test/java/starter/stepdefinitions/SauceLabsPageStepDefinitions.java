package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Hit;
import net.serenitybdd.screenplay.ensure.Ensure;
import net.serenitybdd.screenplay.waits.WaitUntil;
import org.openqa.selenium.Keys;
import starter.navigation.NavigateTo;
import starter.targets.SauceLabs;

import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isVisible;

public class SauceLabsPageStepDefinitions {

    @Given("{actor} logs in to the Swag Labs website")
    public void userLogsInToTheSwagLabsWebsite(Actor actor) {
        actor.attemptsTo(
                NavigateTo.theSauceLabsPage()
        );
    }

    @And("{actor} adds to cart the product {string}")
    public void heAddsToCartTheProduct(Actor actor, String itemName) {
        actor.attemptsTo(
                Click.on(SauceLabs.AddToCartItem_withItemName.of(itemName))
        );
    }

    @And("{actor} goes to the shopping cart")
    public void heGoesToTheShoppingCart(Actor actor) {
        actor.attemptsTo(
                Click.on(SauceLabs.ShoppingCart)
        );
    }

    @Then("{actor} sees that there are {string} products successfully added to the cart")
    public void heSeesThatThereAreProductsSuccessfullyAddedToTheCart(Actor actor, String numberOfProducts) {
        int numberOfProductsInt = Integer.parseInt(numberOfProducts);
        int displayedCartItems = SauceLabs.CartItemCount.resolveAllFor(actor).size();

        actor.attemptsTo(
                Ensure.that(numberOfProductsInt).isEqualTo(displayedCartItems)
        );
    }

    @When("{actor} clicks the checkout button")
    public void heClicksTheCheckoutButton(Actor actor) {
        actor.attemptsTo(
                Click.on(SauceLabs.CheckoutButton)
        );
    }

    @And("{actor} enters {string} in the first name field")
    public void heEntersInTheFirstNameField(Actor actor, String firstname) {
        actor.attemptsTo(
                Enter.theValue(firstname).into(SauceLabs.FirstNameField)
        );
    }

    @And("{actor} enters {string} in the last name field")
    public void heEntersInTheLastNameField(Actor actor, String lastName) {
        actor.attemptsTo(
                Enter.theValue(lastName).into(SauceLabs.LastNameField)
        );
    }

    @And("{actor} enters {string} in the zip code")
    public void heEntersInTheZipCode(Actor actor, String postalCode) {
        actor.attemptsTo(
                Enter.theValue(postalCode).into(SauceLabs.PostalCodeField)
        );
    }

    @And("{actor} clicks the continue button")
    public void heClicksTheContinueButton(Actor actor) {
        actor.attemptsTo(
                Click.on(SauceLabs.ContinueButton)
        );
    }

    @Then("{actor} sees that there are {string} products in the checkout page")
    public void heSeesThatThereAreProductsInTheCheckoutPage(Actor actor, String numberOfProducts) {
        int numberOfProductsInt = Integer.parseInt(numberOfProducts);
        int displayedCartItems = SauceLabs.CartItemCount.resolveAllFor(actor).size();

        actor.attemptsTo(
                Ensure.that(numberOfProductsInt).isEqualTo(displayedCartItems)
        );
    }

    @And("{actor} sees that the Payment and Shipping details are displayed")
    public void heSeesThatThePaymentAndShippingDetailsAreDisplayed(Actor actor) {
        actor.attemptsTo(
                WaitUntil.the(SauceLabs.SummaryInfoBody, isVisible()).forNoMoreThan(60).seconds()
        );

        actor.attemptsTo(
                Ensure.that(SauceLabs.SummaryInfoBody).isDisplayed()
        );
    }

    @When("{actor} clicks the finish button")
    public void heClicksTheFinishButton(Actor actor) {
        actor.attemptsTo(
                Click.on(SauceLabs.FinishButton)
        );
    }


    @Then("{actor} sees that the order has been successfully placed")
    public void heSeesThatTheOrderHasBeenSuccessfullyPlaced(Actor actor) {
        actor.attemptsTo(
                WaitUntil.the(SauceLabs.CheckoutCompleteBody, isVisible()).forNoMoreThan(60).seconds()
        );

        actor.attemptsTo(
                Ensure.that(SauceLabs.ThankyouMessage).isDisplayed()
        );
    }

    @Then("{actor} sees the log in page")
    public void heSeesTheLogInPage(Actor actor) {
        actor.attemptsTo(
                Ensure.that(SauceLabs.LoginPageBody).isDisplayed()
        );
    }

    @When("{actor} enters the log in details")
    public void heEntersTheLogInDetails(Actor actor) {
        String username = "standard_user";
        String password = "secret_sauce";

        actor.attemptsTo(
                Enter.theValue(username).into(SauceLabs.UserNameField),
                Hit.the(Keys.TAB).into(SauceLabs.UserNameField),
                Enter.theValue(password).into(SauceLabs.PasswordField),
                Hit.the(Keys.TAB).into(SauceLabs.PasswordField)
        );

        actor.attemptsTo(
                Click.on(SauceLabs.LoginButton)
        );
    }

    @Then("{actor} sees that the homepage is displayed")
    public void heSeesThatTheHomepageIsDisplayed(Actor actor) {
        actor.attemptsTo(
                WaitUntil.the(SauceLabs.HomePageContainer, isVisible()).forNoMoreThan(60)
                        .seconds()
        );

        actor.attemptsTo(
                Ensure.that(SauceLabs.HomePageContainer).isDisplayed()
        );
    }
}
