package starter.stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.ensure.Ensure;
import net.serenitybdd.screenplay.questions.page.TheWebPage;
import starter.navigation.NavigateTo;
import starter.search.LookForInformation;

public class JupiterHomePageStepDefinitions {

    @Given("{actor} opens the Jupiter Toys page")
    public void userOpensTheJupiterToysPage(Actor actor) {
        actor.attemptsTo(
            NavigateTo.theJupiterPage()
        );
    }

}
