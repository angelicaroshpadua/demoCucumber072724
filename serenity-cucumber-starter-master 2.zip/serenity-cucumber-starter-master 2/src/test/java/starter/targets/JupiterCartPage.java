package starter.targets;

import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.pages.PageObject;

public class JupiterCartPage extends PageObject {

    public static final Target CART_ITEMS_TABLE = Target
            .the(" Cart Items Table")
            .locatedBy("//table[contains(@class, 'cart-items')]");

    public static final Target UNIT_PRICE_withItemName = Target
            .the(" Unit Price for item {0}")
            .locatedBy("//table//tbody//td[contains(text(),'{0}')]/..//td[2]");

    public static final Target QUANTITY_FIELD_withItemName = Target
            .the(" Quantity Field for item {0}")
            .locatedBy("//table//tbody//td[contains(text(),'{0}')]/..//td//input[@name='quantity']");

    public static final Target SUBTOTAL_withItemName = Target
            .the(" Subtotal for item {0}")
            .locatedBy("//table//tbody//td[contains(text(),'{0}')]/..//td[4]");

    public static final Target TABLE_ITEMS_ROW_COUNT = Target
            .the(" Table Items Row count")
            .locatedBy("//table//tbody//tr");

    public static final Target SUBTOTAL_OF_ITEM_withRowNumber = Target
            .the(" Subtotal of item with row number {0}")
            .locatedBy("//table//tbody//tr[{0}]//td[4]");

    public static final Target TOTAL_PRICE_OF_ITEMS = Target
            .the(" Subtotal of item with row number {0}")
            .locatedBy("//tfoot//td//strong[contains(@class, 'total')]");

}