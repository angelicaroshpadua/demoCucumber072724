package starter.targets;

import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.pages.PageObject;

public class SauceLabs extends PageObject {

    public static final Target LoginPageBody = Target
            .the(" Login Page")
            .locatedBy("//div[@class='login_container']");

    public static final Target UserNameField = Target
            .the(" UserName Field")
            .locatedBy("//input[@name='user-name']");

    public static final Target PasswordField = Target
            .the(" Password Field")
            .locatedBy("//input[@name='password']");

    public static final Target LoginButton = Target
            .the(" Login Button")
            .locatedBy("//input[@type='submit']");

    public static final Target HomePageContainer = Target
            .the(" Home Page")
            .locatedBy("//div[@class='inventory_container']");

    public static final Target AddToCartItem_withItemName = Target
            .the(" AddToCart button of Item name {0}")
            .locatedBy("//div[@data-test='inventory-item-name' and text()='{0}']/../../..//button[text()='Add to cart']");

    public static final Target ShoppingCart = Target
            .the(" Shopping Cart Button")
            .locatedBy("//a[@class='shopping_cart_link']");


    public static final Target CartItemCount = Target
            .the(" CartItem count")
            .locatedBy("//div[@class='cart_list']//div[@class='cart_item']");

    public static final Target CheckoutButton = Target
            .the(" Checkout button")
            .locatedBy("//button[@id='checkout']");


    public static final Target FirstNameField = Target
            .the(" First Name Field")
            .locatedBy("//input[@name='firstName']");

    public static final Target LastNameField = Target
            .the(" Last Name Field")
            .locatedBy("//input[@name='lastName']");

    public static final Target PostalCodeField = Target
            .the(" Postalcode Field")
            .locatedBy("//input[@name='postalCode']");

    public static final Target ContinueButton = Target
            .the(" Continue Button")
            .locatedBy("//input[@value='Continue']");


    public static final Target SummaryInfoBody = Target
            .the(" Summary info Body")
            .locatedBy("//div[@class='summary_info']");


    public static final Target FinishButton = Target
            .the(" FinishButton")
            .locatedBy("//button[@id='finish']");

    public static final Target CheckoutCompleteBody = Target
            .the(" Checkout Body")
            .locatedBy("//div[@id='checkout_complete_container']");

    public static final Target ThankyouMessage = Target
            .the(" Thank you Message - Checkout Body")
            .locatedBy("//h2[@class='complete-header' and text()='Thank you for your order!']");






    //input[@name='']
    //input[@name='']

}